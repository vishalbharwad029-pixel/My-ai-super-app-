const messagesEl = document.getElementById("messages");
const form = document.getElementById("chatForm");
const input = document.getElementById("promptInput");
const statusEl = document.getElementById("status");
const imageInput = document.getElementById("imageInput");
const previewWrap = document.getElementById("imagePreviewWrap");
const preview = document.getElementById("imagePreview");
const voiceBtn = document.getElementById("voiceBtn");
const STORAGE_KEY = "my-ai-super-chat-v1";
const LANG_KEY = "my-ai-super-language";
let chat = [];
let selectedImageData = null;
let selectedImageType = null;
let activeFeature = "chat";
let recognition = null;

const ui = {
  gu: {
    tagline:"તમારો ઓલ-ઇન-વન AI સહાયક", languageLabel:"ભાષા", navChat:"AI ચેટ", navPhoto:"ફોટો સ્ટુડિયો", navStudy:"અભ્યાસ", navBusiness:"બિઝનેસ", navCoding:"કોડિંગ", navCyber:"સાયબર સુરક્ષા",
    toolsHeading:"ઝડપી ટૂલ્સ", summarize:"લખાણનો સારાંશ", studyPlan:"અભ્યાસનું આયોજન", businessPlan:"બિઝનેસ પ્લાન", photoPrompt:"ફોટો માટે પ્રોમ્પ્ટ", secure:"મારી સુરક્ષા સુધારો",
    clear:"આ ચેટ સાફ કરો", storageNote:"ચેટ આ ડિવાઇસના બ્રાઉઝરમાં સાચવાય છે.", welcomeTitle:"MY AI માં સ્વાગત છે", welcomeText:"ટૂલ પસંદ કરો અથવા પ્રશ્ન પૂછો. ફોટો અપલોડ કરો અથવા અવાજથી મેસેજ લખો.",
    placeholder:"MY AI ને મેસેજ લખો...", disclaimer:"AIની ભૂલ થઈ શકે છે. પાસવર્ડ કે સંવેદનશીલ માહિતી ન લખશો.", listening:"સાંભળી રહ્યું છે… હવે બોલો.", thinking:"MY AI વિચારી રહ્યું છે…",
    prompts:{
      summarize:"આ લખાણનો સરળ ગુજરાતી ભાષામાં સારાંશ આપો: ",
      studyPlan:"મારા માટે વિષય પ્રમાણે અભ્યાસનું સમયપત્રક બનાવો. પહેલાં જરૂરી માહિતી પૂછો.",
      businessPlan:"નાના બિઝનેસ માટે વ્યવહારુ બિઝનેસ પ્લાન બનાવવામાં મદદ કરો. બજેટ અને સ્થળ વિશે પહેલાં પૂછો.",
      photoPrompt:"મારે AIથી સુંદર ફોટો બનાવવો છે. મારી કલ્પના પૂછો અને પછી વિગતવાર image prompt બનાવો.",
      secure:"મારા પોતાના એકાઉન્ટ અને ડિવાઇસની સાયબર સુરક્ષા સુધારવા માટે કાયદેસર પગલાં સમજાવો."
    },
    featureText:{
      chat:["AI સાથે વાત કરો","કોઈપણ પ્રશ્ન પૂછો; જવાબ તમારી પસંદગીની ભાષામાં માગી શકો છો."],
      photo:["AI ફોટો સ્ટુડિયો","ફોટો અપલોડ કરીને સમજાવો અથવા એડિટિંગ માટે સૂચનાઓ મેળવો. નવો ફોટો બનાવવા માટે પાછળથી image-generation API જોડવી પડશે."],
      study:["Study AI","નોટ્સ, ગણિત, MCQ અને અભ્યાસ યોજના માટે પ્રશ્ન પૂછો."],
      business:["Business AI","બિઝનેસ વિચારો, માર્કેટિંગ અને ખર્ચ-નફાની યોજના બનાવો."],
      coding:["Coding AI","કોડ સમજાવો, ભૂલો શોધો અને પોતાની એપ બનાવતાં શીખો."],
      cyber:["Cyber Safety Lab","પોતાના એકાઉન્ટ અને અધિકૃત ટેસ્ટ લેબની સુરક્ષા શીખો. બીજાના એકાઉન્ટમાં ગેરકાયદે પ્રવેશ માટે નહીં."]
    },
    newChat:"નવી ચેટ શરૂ થઈ.", cleared:"આ બ્રાઉઝરની ચેટ સાફ થઈ.", imageReady:"ફોટો મોકલવા તૈયાર છે.", noInput:"મેસેજ લખો અથવા ફોટો જોડો.", listeningError:"અવાજની ભૂલ: "
  },
  hi: {
    tagline:"आपका ऑल-इन-वन AI सहायक", languageLabel:"भाषा", navChat:"AI चैट", navPhoto:"फोटो स्टूडियो", navStudy:"पढ़ाई", navBusiness:"बिज़नेस", navCoding:"कोडिंग", navCyber:"साइबर सुरक्षा",
    toolsHeading:"त्वरित टूल", summarize:"टेक्स्ट का सारांश", studyPlan:"स्टडी प्लान", businessPlan:"बिज़नेस प्लान", photoPrompt:"फोटो प्रॉम्प्ट", secure:"मेरी सुरक्षा सुधारें",
    clear:"यह चैट मिटाएँ", storageNote:"चैट इसी डिवाइस के ब्राउज़र में सेव होती है।", welcomeTitle:"MY AI में आपका स्वागत है", welcomeText:"कोई टूल चुनें या सवाल पूछें। फोटो अपलोड करें या आवाज़ से संदेश लिखें।",
    placeholder:"MY AI को संदेश लिखें...", disclaimer:"AI से गलती हो सकती है। पासवर्ड या संवेदनशील जानकारी न लिखें।", listening:"सुन रहा है… अब बोलें।", thinking:"MY AI सोच रहा है…",
    prompts:{
      summarize:"इस टेक्स्ट का आसान हिंदी में सारांश दें: ",
      studyPlan:"मेरे लिए विषय के अनुसार पढ़ाई का टाइमटेबल बनाइए। पहले ज़रूरी जानकारी पूछें।",
      businessPlan:"छोटे बिज़नेस के लिए व्यावहारिक बिज़नेस प्लान बनाने में मदद करें। पहले बजट और जगह पूछें।",
      photoPrompt:"मुझे AI से एक सुंदर तस्वीर बनानी है। मेरी कल्पना पूछें और फिर विस्तृत image prompt बनाएं।",
      secure:"मेरे अपने अकाउंट और डिवाइस की साइबर सुरक्षा बेहतर करने के कानूनी तरीके बताएं।"
    },
    featureText:{
      chat:["AI से बात करें","कोई भी सवाल पूछें और अपनी पसंद की भाषा में जवाब माँगें।"],
      photo:["AI फोटो स्टूडियो","फोटो अपलोड करके उसके बारे में पूछें या एडिटिंग के निर्देश लें। नई तस्वीर बनाने के लिए बाद में image-generation API जोड़नी होगी।"],
      study:["Study AI","नोट्स, गणित, MCQ और पढ़ाई की योजना के लिए सवाल पूछें।"],
      business:["Business AI","बिज़नेस आइडिया, मार्केटिंग और खर्च-लाभ की योजना बनाएं।"],
      coding:["Coding AI","कोड समझें, गलतियाँ खोजें और अपनी ऐप बनाना सीखें।"],
      cyber:["Cyber Safety Lab","अपने अकाउंट और अधिकृत टेस्ट लैब की सुरक्षा सीखें। दूसरों के अकाउंट में गैरकानूनी प्रवेश के लिए नहीं।"]
    },
    newChat:"नई चैट शुरू हुई।", cleared:"इस ब्राउज़र की चैट मिटा दी गई।", imageReady:"फोटो भेजने के लिए तैयार है।", noInput:"संदेश लिखें या फोटो जोड़ें।", listeningError:"वॉइस इनपुट त्रुटि: "
  },
  en: {
    tagline:"Your all-in-one AI assistant", languageLabel:"Language", navChat:"AI Chat", navPhoto:"Photo Studio", navStudy:"Study", navBusiness:"Business", navCoding:"Coding", navCyber:"Cyber Safety",
    toolsHeading:"Quick tools", summarize:"Summarize text", studyPlan:"Make a study plan", businessPlan:"Business plan", photoPrompt:"Create an image prompt", secure:"Improve my security",
    clear:"Clear this chat", storageNote:"Chat history is saved in this browser on this device.", welcomeTitle:"Welcome to MY AI", welcomeText:"Choose a tool or ask a question. Upload a picture or use voice input.",
    placeholder:"Message MY AI...", disclaimer:"AI can make mistakes. Don't enter passwords or sensitive information.", listening:"Listening… speak now.", thinking:"MY AI is thinking…",
    prompts:{
      summarize:"Summarize this text in clear, simple English: ",
      studyPlan:"Create a subject-wise study timetable for me. Ask for the necessary details first.",
      businessPlan:"Help me make a practical business plan for a small business. Ask about my budget and location first.",
      photoPrompt:"I want to create an image with AI. Ask about my idea and then write a detailed image-generation prompt.",
      secure:"Explain legal steps to improve cybersecurity for my own accounts and devices."
    },
    featureText:{
      chat:["Welcome to MY AI","Ask a question. You can request an answer in your preferred language."],
      photo:["AI Photo Studio","Upload an image to ask questions or get editing instructions. Image generation requires connecting an image-generation API later."],
      study:["Study AI","Ask for notes, math explanations, MCQs, and study plans."],
      business:["Business AI","Develop business ideas, marketing copy, and cost/profit plans."],
      coding:["Coding AI","Explain code, find bugs, and learn to build your own app."],
      cyber:["Cyber Safety Lab","Learn to secure your own accounts and authorized test labs—not to break into others' accounts."]
    },
    newChat:"New chat started.", cleared:"This browser's chat history was cleared.", imageReady:"Image ready to send.", noInput:"Type a message or attach a picture.", listeningError:"Voice input error: "
  }
};
let lang = localStorage.getItem(LANG_KEY) || "gu";

function t(key) { return (ui[lang] && ui[lang][key]) || ui.en[key] || key; }
function applyLanguage() {
  document.documentElement.lang = lang;
  document.getElementById("languageSelect").value = lang;
  document.getElementById("tagline").textContent = t("tagline");
  document.getElementById("languageLabel").textContent = t("languageLabel");
  document.getElementById("toolsHeading").textContent = t("toolsHeading");
  document.getElementById("clearBtn").textContent = t("clear");
  document.getElementById("storageNote").textContent = t("storageNote");
  document.getElementById("promptInput").placeholder = t("placeholder");
  document.getElementById("promptInput").setAttribute("aria-label", t("placeholder"));
  document.getElementById("disclaimer").textContent = t("disclaimer");
  document.querySelectorAll("[data-i18n]").forEach(el => { const key=el.dataset.i18n; if(t(key)) el.textContent=t(key); });
  updateFeatureIntro();
}
function updateFeatureIntro() {
  const data = ui[lang].featureText[activeFeature] || ui.en.featureText[activeFeature];
  document.getElementById("welcomeTitle").textContent = data[0];
  document.getElementById("welcomeText").textContent = data[1];
}
function addBubble(role, text, imageData=null) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  if (imageData) { const img=document.createElement("img"); img.src=imageData; img.alt="Uploaded picture"; div.appendChild(img); }
  const content=document.createElement("div"); content.textContent=text; div.appendChild(content);
  messagesEl.appendChild(div); messagesEl.scrollTop=messagesEl.scrollHeight;
}
function saveChat() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(chat)); } catch(e) {} }
function renderChat() {
  messagesEl.innerHTML = "";
  chat.forEach(m => addBubble(m.role, m.text, m.image || null));
}
function resetImage() {
  selectedImageData=null; selectedImageType=null; imageInput.value="";
  preview.src=""; previewWrap.classList.add("hidden");
}
document.getElementById("languageSelect").addEventListener("change", e => {
  lang=e.target.value; localStorage.setItem(LANG_KEY,lang); applyLanguage();
});
document.querySelectorAll(".feature").forEach(btn => btn.addEventListener("click", () => {
  activeFeature=btn.dataset.feature;
  document.querySelectorAll(".feature").forEach(b=>b.classList.toggle("active",b===btn));
  updateFeatureIntro();
  const prompts = {
    photo:{gu:"મને ફોટો બનાવવા અથવા એડિટ કરવા માટે મદદ કરો.",hi:"फोटो बनाने या एडिट करने में मेरी मदद करें।",en:"Help me create or edit an image."},
    study:{gu:"મને અભ્યાસમાં મદદ કરો.",hi:"मेरी पढ़ाई में मदद करें।",en:"Help me study."},
    business:{gu:"મને બિઝનેસ પ્લાન બનાવવામાં મદદ કરો.",hi:"बिज़नेस प्लान बनाने में मदद करें।",en:"Help me create a business plan."},
    coding:{gu:"મને કોડિંગ શીખવામાં મદદ કરો.",hi:"मुझे कोडिंग सीखने में मदद करें।",en:"Help me learn coding."},
    cyber:{gu:"મને કાયદેસર સાયબર સુરક્ષા શીખવો.",hi:"मुझे कानूनी साइबर सुरक्षा सिखाएँ।",en:"Teach me legal cybersecurity."}
  };
  if (activeFeature!=="chat") input.value=(prompts[activeFeature]||{})[lang] || (prompts[activeFeature]||{}).en || "";
  input.focus();
}));
document.querySelectorAll(".quick-tool").forEach(btn => btn.addEventListener("click", () => {
  input.value = ui[lang].prompts[btn.dataset.promptKey] || ui.en.prompts[btn.dataset.promptKey] || "";
  input.focus(); input.dispatchEvent(new Event("input"));
}));
document.getElementById("newChatBtn").addEventListener("click", () => {
  chat=[]; saveChat(); renderChat(); resetImage(); statusEl.textContent=t("newChat");
});
document.getElementById("clearBtn").addEventListener("click", () => {
  chat=[]; saveChat(); renderChat(); resetImage(); statusEl.textContent=t("cleared");
});
document.getElementById("attachBtn").addEventListener("click", () => imageInput.click());
imageInput.addEventListener("change", () => {
  const file=imageInput.files && imageInput.files[0]; if(!file) return;
  if(!["image/png","image/jpeg","image/webp"].includes(file.type)){statusEl.textContent="Please choose PNG, JPG, or WEBP.";resetImage();return;}
  if(file.size>5*1024*1024){statusEl.textContent="Please choose an image smaller than 5 MB.";resetImage();return;}
  const reader=new FileReader(); reader.onload=()=>{selectedImageData=reader.result;selectedImageType=file.type;preview.src=selectedImageData;previewWrap.classList.remove("hidden");statusEl.textContent=t("imageReady");};reader.readAsDataURL(file);
});
document.getElementById("removeImageBtn").addEventListener("click",resetImage);
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,140)+"px";});

form.addEventListener("submit", async event => {
  event.preventDefault();
  const text=input.value.trim();
  if(!text&&!selectedImageData){statusEl.textContent=t("noInput");return;}
  const image=selectedImageData, imageType=selectedImageType;
  const userText=text||(lang==="gu"?"આ ફોટો સમજાવો.":lang==="hi"?"इस फोटो को समझाएँ।":"Please describe this image.");
  chat.push({role:"user",text:userText,image:image||null}); addBubble("user",userText,image); saveChat();
  input.value="";input.style.height="auto";resetImage();statusEl.textContent=t("thinking");
  const sendBtn=document.getElementById("sendBtn");sendBtn.disabled=true;
  try{
    const apiBase=(window.MY_AI_API_BASE||"").replace(/\/$/,"");
    const response=await fetch(`${apiBase}/api/chat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      message:userText,language:lang,feature:activeFeature,
      history:chat.slice(-12).map(m=>({role:m.role,text:m.text})),
      image_data:image||null,image_type:imageType||null
    })});
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data.detail||"Request failed. Check the backend setup.");
    const answer=data.reply||"No reply received.";
    chat.push({role:"assistant",text:answer});addBubble("assistant",answer);saveChat();statusEl.textContent="";
  }catch(err){
    const msg="Couldn't reach the AI service. Make sure the backend is running and OPENAI_API_KEY is set. "+err.message;
    statusEl.textContent=msg;addBubble("assistant",msg);
  }finally{sendBtn.disabled=false;input.focus();}
});

const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SpeechRecognition){
  recognition=new SpeechRecognition();recognition.interimResults=false;recognition.maxAlternatives=1;
  const voiceLang={gu:"gu-IN",hi:"hi-IN",en:"en-US"};
  recognition.onstart=()=>{voiceBtn.classList.add("recording");statusEl.textContent=t("listening");};
  recognition.onend=()=>{voiceBtn.classList.remove("recording");if(statusEl.textContent===t("listening"))statusEl.textContent="";};
  recognition.onerror=e=>{voiceBtn.classList.remove("recording");statusEl.textContent=t("listeningError")+e.error;};
  recognition.onresult=e=>{input.value=(input.value?input.value+" ":"")+e.results[0][0].transcript;input.dispatchEvent(new Event("input"));input.focus();};
  voiceBtn.addEventListener("click",()=>{recognition.lang=voiceLang[lang]||"en-US";try{recognition.start();}catch(e){statusEl.textContent="Voice input is already active.";}})
}else{voiceBtn.addEventListener("click",()=>{statusEl.textContent="Voice input is not supported in this browser. Try Chrome or type your message.";});}

try{chat=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");if(!Array.isArray(chat))chat=[];}catch(e){chat=[];}
applyLanguage();renderChat();


// Progressive Web App support: enables install prompt on supported HTTPS hosts.
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}
