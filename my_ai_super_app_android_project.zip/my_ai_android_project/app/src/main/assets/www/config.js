// Set this to your hosted backend URL (HTTPS) when it is available, e.g. https://your-backend.example
// Leave empty for same-origin web hosting. Never put an API key in this file.
window.MY_AI_API_BASE = "";
